// parent-auth.js - سیستم احراز هویت والدین

const PARENT_SESSION_KEY = 'parent_session';

class ParentAuth {
    constructor() {
        this.STORAGE_KEY = 'portfolio_database_v1';
        this.data = this.loadData();
        this.session = this.getSession();
    }
    
    loadData() {
        try {
            const saved = localStorage.getItem(this.STORAGE_KEY);
            if (saved) {
                const parsed = JSON.parse(saved);
                if (!parsed.parentSessions) parsed.parentSessions = {};
                if (!parsed.studentPasswords) parsed.studentPasswords = {};
                return parsed;
            }
        } catch (error) {
            console.error('Error loading data:', error);
        }
        return {
            students: [],
            evaluations: {},
            goals: {},
            parentData: {},
            teacherNotes: {},
            studentPasswords: {},
            parentSessions: {}
        };
    }
    
    saveData() {
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.data));
    }
    
    // ============================================
    // SESSION MANAGEMENT
    // ============================================
    getSession() {
        try {
            const session = localStorage.getItem(PARENT_SESSION_KEY);
            return session ? JSON.parse(session) : null;
        } catch (e) {
            return null;
        }
    }
    
    setSession(parentData) {
        const session = {
            studentId: parentData.studentId,
            studentName: parentData.studentName,
            parentName: parentData.parentName,
            loginTime: new Date().toISOString()
        };
        localStorage.setItem(PARENT_SESSION_KEY, JSON.stringify(session));
        this.session = session;
    }
    
    clearSession() {
        localStorage.removeItem(PARENT_SESSION_KEY);
        this.session = null;
    }
    
    isLoggedIn() {
        return !!this.session;
    }
    
    getCurrentParent() {
        return this.session;
    }
    
    // ============================================
    // AUTHENTICATION
    // ============================================
    login(studentId, parentName, password) {
        const student = this.data.students.find(s => s.id === studentId);
        if (!student) {
            return { success: false, message: '❌ دانش‌آموز یافت نشد.' };
        }
        
        const key = `${student.name}_${student.grade}`;
        const correctPassword = this.data.studentPasswords[key] || '123456';
        
        if (password !== correctPassword) {
            return { success: false, message: '❌ رمز عبور اشتباه است.' };
        }
        
        // ثبت یا به‌روزرسانی اطلاعات والدین
        if (!this.data.parentSessions) this.data.parentSessions = {};
        this.data.parentSessions[studentId] = {
            parentName: parentName,
            lastLogin: new Date().toISOString()
        };
        
        this.setSession({
            studentId: student.id,
            studentName: student.name,
            parentName: parentName
        });
        
        this.saveData();
        return { success: true, message: '✅ ورود با موفقیت انجام شد!', student: student };
    }
    
    logout() {
        this.clearSession();
    }
    
    // ============================================
    // DATA ACCESS (برای والدین)
    // ============================================
    getStudentId() {
        return this.session ? this.session.studentId : null;
    }
    
    getStudent() {
        const studentId = this.getStudentId();
        if (!studentId) return null;
        return this.data.students.find(s => s.id === studentId);
    }
    
    getStudentName() {
        return this.session ? this.session.studentName : null;
    }
    
    getParentName() {
        return this.session ? this.session.parentName : null;
    }
    
    getEvaluations() {
        const id = this.getStudentId();
        if (!id) return {};
        return (this.data.evaluations && this.data.evaluations[id]) || {};
    }
    
    getGoals() {
        const id = this.getStudentId();
        if (!id) return [];
        return (this.data.goals && this.data.goals[id]) || [];
    }
    
    getNotes() {
        const id = this.getStudentId();
        if (!id) return [];
        return (this.data.teacherNotes && this.data.teacherNotes[id]) || [];
    }
    
    getParentData() {
        const id = this.getStudentId();
        if (!id) return null;
        return this.data.parentData[id] || null;
    }
    
    // ============================================
    // SEND FEEDBACK
    // ============================================
    sendFeedback(studentId, message) {
        if (!this.data.parentFeedback) this.data.parentFeedback = {};
        if (!this.data.parentFeedback[studentId]) this.data.parentFeedback[studentId] = [];
        
        const feedback = {
            id: 'fb_' + Date.now(),
            parentName: this.getParentName() || 'والدین',
            message: message,
            createdAt: new Date().toISOString(),
            read: false
        };
        
        this.data.parentFeedback[studentId].push(feedback);
        this.saveData();
        return feedback;
    }
    
    getFeedback(studentId) {
        return (this.data.parentFeedback && this.data.parentFeedback[studentId]) || [];
    }
}

// Export to global scope
window.ParentAuth = ParentAuth;

console.log('👨‍👩‍👧 سیستم احراز هویت والدین بارگذاری شد!');